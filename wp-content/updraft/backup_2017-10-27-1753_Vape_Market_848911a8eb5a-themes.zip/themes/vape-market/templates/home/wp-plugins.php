<div class="vm-row">
	<div class="vm-col-12">

		<h2>WordPress Plugin Development</h2>
		<h4>GoldHat Group currently has 8 plugins in the official WordPress plugin directory, with many more on the way.</h4>

		<div class="vm-row">
			<div class="vm-col-3">
				<img src="" width="200" height="150" alt="quizmaster" />
				<h2>
					QuizMaster
				</h2>
				<p>QuizMaster is a powerful, highly extendable quiz plugin for WordPress.</p>
			</div>
		</div>

	</div>
</div>

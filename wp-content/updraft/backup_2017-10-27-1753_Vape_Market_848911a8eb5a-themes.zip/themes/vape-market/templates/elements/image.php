<div class="vm-image">
	<img src="" />
</div>

<?php

class Vape_Market_Menu {

	public function register( $key, $name ) {

		register_nav_menu( $key, $name );

	}

	// create nav menus
	// https://codex.wordpress.org/Function_Reference/wp_create_nav_menu

}

=== Bootstrap Integration ===

Contributors: mcostales84
Donate Link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=VWWTUHZWRS4DG
Tags: bootstrap, twitter framework, responsive
Requires at least: 3.1
Tested up to: 4.5.2
Stable tag: 2.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

For those templates which don't came with bootstrap libraries, this plugin integrate the style and the script (version 3.3.6) with your wordpress installation. 

== Description ==

Now you can write code and be sure your website is responsive and clean.

If you need some ideas just check some examples in the Bootstrap website:
http://getbootstrap.com/getting-started/#examples

If you need some help with the css classes, check this link:
http://getbootstrap.com/css

== Installation ==

To install this plugin just follow the standard procedure.

or

1. Upload `bootstrap-integration.zip` to the `/wp-content/plugins/` directory
2. Unzipped it
3. Activate the plugin through the 'Plugins' menu in WordPress
4. Enjoy it!

== Frequently Asked Questions ==

= Any question? =

Send me an email at mcostales@jumptoweb.com and I will answer you as soon as I can.

== Changelog ==

= 2.0 =
Update to version 3.3.5 of Bootstrap.

= 1.0 =
Just launch the plugin!
